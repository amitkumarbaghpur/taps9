<?php
include('config/function.php');
$use_charli = new ecom();
$use_charli->logout();
?>
