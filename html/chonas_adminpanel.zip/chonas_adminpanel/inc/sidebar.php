
  <div class="page-wrapper">
        <div class="page-content">
<!--navigation-->
		<!--sidebar wrapper -->
<div class="sidebar-wrapper" data-simplebar="true">
            <div class="sidebar-header">
                <div>
                    <img src="assets/images/logo-icon.png" class="logo-icon" alt="logo icon">
                </div>
                <div>
                    <h4 class="logo-text"> Master Panel </h4>
                </div>
                <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
                </div>
            </div>
            <!--navigation-->
            <ul class="metismenu" id="menu">
                <li>
                     <li>
                    <a href="index.php" >
                        <div class="parent-icon"><i class='bx bx-home-circle'></i>
                        </div>
                        <div class="menu-title">Dashboard</div>
                       
                    </a>
                     </li>  
                    
  
                  <li>
                    <a class="has-arrow" href="javascript:;">
                        <div class="parent-icon"><i class="bx bx-grid-alt"></i>
                        </div>
                        <div class="menu-title">Manage Category </div>
                    </a>
                    <ul> 
                        <li> <a href="add-category.php"><i class="bx bx-right-arrow-alt"></i>Add Category</a>
                        </li>
                        <li> <a href="manage-category.php"><i class="bx bx-right-arrow-alt"></i>Manage Category</a>
                        </li>
                        <!--   <li> <a href="manage-sub-category.php"><i class="bx bx-right-arrow-alt"></i>Manage Sub Category</a>
                        </li> -->
                          
                    </ul>
                </li>
                    
  
                  <li>
                    <a class="has-arrow" href="javascript:;">
                        <div class="parent-icon"><i class="bx bx-grid-alt"></i>
                        </div>
                        <div class="menu-title">Manage Product </div>
                    </a>
                    <ul>  
                        <li> <a href="add-product.php"><i class="bx bx-right-arrow-alt"></i>Add Product</a>
                        </li>
                         <li> <a href="manage-product.php"><i class="bx bx-right-arrow-alt"></i>Manage Product</a>
                        </li>
                    </ul>
                </li>

                



                 
                <li>
                    <a href="order-list.php" >
                        <div class="parent-icon"><i class='bx bx-grid-alt'></i>
                        </div>
                        <div class="menu-title">Order List</div>
                       
                    </a>
                </li> 
                 
                <li>
                    <a href="add-coupon-code.php" >
                        <div class="parent-icon"><i class='bx bx-grid-alt'></i>
                        </div>
                        <div class="menu-title">Coupon Code</div>
                       
                    </a>
                </li> 
                 

                  <li>
                    <a class="has-arrow" href="javascript:;">
                        <div class="parent-icon"><i class="bx bx-grid-alt"></i>
                        </div>
                        <div class="menu-title"> Register customer </div>
                    </a>
                    <ul>
                         <li> <a href="customer_list.php"><i class="bx bx-right-arrow-alt"></i> View customer</a> </li>
                        
                         
                    </ul>
                </li>


 
 

                </li>
           </ul>
            <!--end navigation-->
        </div>
        <!--end sidebar wrapper -->		<!--end navigation-->
		