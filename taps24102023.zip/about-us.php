<?php include('include/header.php'); ?>
      <div class="container-fluid aboutus" id="page">
         <div class="container">
            <div class="bn2">
               <h3>About Us</h3>
               <p>
                  <a href="index.html">Home &nbsp; </a> / &nbsp;
                  <a href="about-us.html" style="color: #68c6ff; font-weight: normal"> About Us</a>
               </p>
            </div>
         </div>
      </div>
      <!-- about us-->
      <div class="section_wrapper">
         <div class="container mb-2">
            <div class="row">
               <div class="col-md-12 aboutt">
                  <h3>About <span class="redcolor">Us</span></h3>
               </div>
            </div>
            <div class="row">
               <div class="col-md-7">
                  <div class="aboutt">
                     <span class="spn1"></span>
                     <p>
                        Taps9 Legal Services provides you with a comprehensive guide and information.
                        We provide services in Matrimonial Matters  which includes  both   
                        Mutual Consent Divorce and Contested Divorce. 
                        Apart from that  we spceialise in  Guardianship  and  Custody rights cases. 
                        We specialise in filing petitions and appeals before the  High Courts and 
                        Special Leave Petitions  before the Supreme Court . we are highly experienced 
                        ,we have a dedicated team of lawyers practicing in family courts .
                        All appeals to High Court are handled by our expert litigations experts
                        solely practicing in High Courts. Our team of lawyers also include
                        Advocate-On-Record in the Supreme Court which makes us a one stop destination for all legal matters .
                        We guide our clients with utmost dedication and honesty.
                        We maintain 100 % confidentiality and a one on one consultation with our clients. We also provide for free filing of Mutual consent divorce cases . The free offers are provided at the home page from time to time .
                     </p>
                  </div>
               </div>
               <div class="col-md-5">
                  <div class="aboutt">
                     <img src="assets/img/lawy1.jpg" alt="" style="border-radius:10px;">
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php include('include/footer.php'); ?>
