<?php
include('config/function.php');
$use_charli = new taps9();
$use_charli->logout();
?>
