<?php include('include/header.php'); ?>

      <div class="container-fluid aboutus" id="page">
         <div class="container">
            <div class="bn2">
               <h3>Privacy Policy</h3>
               <p>
                  <a href="index.html">Home &nbsp; </a> / &nbsp;
                  <a href="privacy-policy.html" style="color: #68c6ff; font-weight: normal">Privacy Policy</a>
               </p>
            </div>
         </div>
      </div>
      <div class="section_wrapper">
         <div class="container mb-2">
            <div class="row">
               <div class="col-md-12 aboutt">
                  <h3>Privacy <span class="redcolor">Policy</span></h3>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="aboutt">
                     <span class="spn1"></span>
                     <p>
                        About us at Taps9 Legal Services is a full time Law office in existence since 1975 . We take this opportunity of paying homage to our founder Sr. Advocate Late Dr N K Dev , MA, LLB, PhD , a role model par excellence and truly the man behind the success story of Taps9 Legal Services chamber .The Law office first started its operations dedicated completely to Family Matters including but not limited to Mutual Consent Divorce, Contested Divorce, Guardianship , Custody rights etc. Filing appeals before the High Courts and Special Leave Petitions in Supreme Court . Our Lawyers are highly experienced ,we have a dedicated team of lawyers practicing in family courts . All appeals to High Court are handled by our expert litigations experts solely practicing in High Courts. Our team of lawyers also include Advocate-On-Record in the Supreme Court which makes us a one stop destination for all legal matters . We guide our clients with utmost dedication and honesty. We maintain 100 % confidentiality and a one on one consultation with our clients. We also provide for free filing of Mutual consent divorce cases . The free offers are provided at the home page from time to time .
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php include('include/footer.php'); ?>
