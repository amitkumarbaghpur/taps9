<?php include('include/header.php'); ?>

      <div class="container-fluid aboutus" id="page">
         <div class="container">
            <div class="bn2">
               <h3>Disclaimer</h3>
               <p>
                  <a href="index.html">Home &nbsp; </a> / &nbsp;
                  <a href="disclaimer.html" style="color: #68c6ff; font-weight: normal">Disclaimer</a>
               </p>
            </div>
         </div>
      </div>
      <div class="section_wrapper">
         <div class="container mb-2">
            <div class="row">
               <div class="col-md-12 aboutt">
                  <h3>Disclaimer <span class="redcolor"></span></h3>
               </div>
            </div>
            <div class="row">
               <div class="col-md-12">
                  <div class="aboutt">
                     <span class="spn1"></span>
                     <p>
                        For informational purpose the site can be used and its contents as well. taps9legalservices.com is a service based website and can be used to find information and services that are provided  , We  however do not  guarantee any consequence when any information is relied upon  by anyone.  You are free to provide us with any  suggestions regarding this website and for that you may  email us at  taps9legalservices@gmail.com
                     </p>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <?php include('include/footer.php'); ?>
