<?php include('include/header.php'); ?>


      <div class="container-fluid lawyerget" id="page">
         <div class="container">
            <div class="bn2">
            </div>
         </div>
      </div>
      <!-- :: Header -->
      
   <div class="details-wrap">
      <div class="container">
         <div class="row">
            <div class="imgbox col-md-4 col-lg-2 advocate-col">
               <a href="get-lawyer-detail.html">
               <img src="assets/img/sudershani.jpg">
               </a>
               <div class="rating">
                  <span class="rateuser">4.6 <i class="fa fa-star"></i></span>
                  <span>100+ user ratings</span>
                </div>
            </div>
            <div class="col-md-8 col-lg-6 getlawer2">
               <div class="innerbox">
                  <div class="find_lawyercontent">
                     <a href="get-lawyer-detail.html">
                        <p><strong>Tapan Choudhury</strong></p>
                     </a>
                       <h5><a href="mailto:tapsash@gmail.com">tapsash@gmail.com</a></h5>
                       <h5><a href="tel:9873628941">9873628941</a></h5>
                       <h5>Haryana</h5>
                       <p><strong>Languages :</strong>English, Hindi </p>
                       <p><strong>Experience :</strong> 29 years </p>
                       <p><strong>Practice area &amp; skills : </strong> Arbitration, Cheque Bounce, Child Custody, Court Marriage, Criminal, Divorce, Documentation, Domestic Violence, Family, High Court, Muslim Law, Property, Recovery </p>
                  </div>

               </div>
            </div>
         </div>
      
      </div>
   </div>
   <?php include('include/footer.php'); ?>
